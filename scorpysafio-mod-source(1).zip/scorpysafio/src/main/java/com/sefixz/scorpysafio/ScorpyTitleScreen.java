package com.sefixz.scorpysafio;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;

import java.util.Random;

public class ScorpyTitleScreen extends Screen {

    // ====== TEXTOS (cámbialos aquí) ======
    private static final String STUDIO_TEXT = "by sefixz";
    private static final String[] LOGO_LINES = {"SCORPY", "SAFIO"};
    // =====================================

    // Fondo opcional: pon un PNG de 1920x1080 en
    // src/main/resources/assets/scorpysafio/textures/gui/background.png
    private static final Identifier BACKGROUND = Identifier.of("scorpysafio", "textures/gui/background.png");
    private static final int BG_W = 1920;
    private static final int BG_H = 1080;

    private static final int STAR_COUNT = 180;

    private boolean hasBackground;
    private float[] starX;
    private float[] starY;
    private float[] starPhase;
    private int[] starSize;

    public ScorpyTitleScreen() {
        super(Text.literal("Scorpy Safio"));
    }

    @Override
    protected void init() {
        hasBackground = client.getResourceManager().getResource(BACKGROUND).isPresent();

        Random rnd = new Random(42);
        starX = new float[STAR_COUNT];
        starY = new float[STAR_COUNT];
        starPhase = new float[STAR_COUNT];
        starSize = new int[STAR_COUNT];
        for (int i = 0; i < STAR_COUNT; i++) {
            starX[i] = rnd.nextFloat();
            starY[i] = rnd.nextFloat();
            starPhase[i] = rnd.nextFloat() * 6.2831f;
            starSize[i] = rnd.nextInt(10) == 0 ? 2 : 1;
        }

        int cx = (int) (width * 0.28f);
        int bw = 200;
        int bh = 30;

        addDrawableChild(new MenuButton(cx, (int) (height * 0.62f), bw, bh,
                Text.literal("JUGAR"), 0xFFFF4D4D,
                b -> client.setScreen(new MultiplayerScreen(this))));

        addDrawableChild(new MenuButton(cx, (int) (height * 0.75f), bw, bh,
                Text.literal("OPCIONES"), 0xFFFFE94D,
                b -> client.setScreen(new OptionsScreen(this, client.options))));

        addDrawableChild(new MenuButton(cx, (int) (height * 0.88f), bw, bh,
                Text.literal("SALIR"), 0xFF4DFF6A,
                b -> client.scheduleStop()));
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        if (hasBackground) {
            ctx.drawTexture(BACKGROUND, 0, 0, width, height, 0f, 0f, BG_W, BG_H, BG_W, BG_H);
            return;
        }

        // Espacio morado -> rojizo
        ctx.fillGradient(0, 0, width, height, 0xFF160A38, 0xFF7A2A3A);

        // Estrellas parpadeando
        float t = (System.currentTimeMillis() % 100000L) / 1000f;
        for (int i = 0; i < STAR_COUNT; i++) {
            float tw = (float) (Math.sin(t * 1.5f + starPhase[i]) + 1.0) * 0.5f;
            int a = 90 + (int) (165 * tw);
            int x = (int) (starX[i] * width);
            int y = (int) (starY[i] * height);
            int s = starSize[i];
            ctx.fill(x, y, x + s, y + s, (a << 24) | 0xFFFFFF);
        }
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta); // fondo + botones

        int cx = (int) (width * 0.28f);

        // "by sefixz" arriba (donde iba Eufonia Studio)
        drawScaledCentered(ctx, Text.literal(STUDIO_TEXT).formatted(Formatting.BOLD),
                cx, (int) (height * 0.05f), 2.2f, 0xFFFFFFFF);

        // Logo: "SCORPY" / "SAFIO"
        int maxW = 1;
        for (String line : LOGO_LINES) {
            maxW = Math.max(maxW, textRenderer.getWidth(Text.literal(line).formatted(Formatting.BOLD)));
        }
        float scale = Math.min(9f, (width * 0.40f) / maxW);
        float lineH = 9f * scale * 1.1f;
        float y = height * 0.15f;
        for (String line : LOGO_LINES) {
            drawLogoLine(ctx, line, cx, y, scale);
            y += lineH;
        }
    }

    private void drawScaledCentered(DrawContext ctx, Text text, int cx, int y, float scale, int color) {
        MatrixStack m = ctx.getMatrices();
        m.push();
        m.translate(cx, y, 0);
        m.scale(scale, scale, 1f);
        ctx.drawCenteredTextWithShadow(textRenderer, text, 0, 0, color);
        m.pop();
    }

    /** Dibuja una línea del logo con extrusión 3D y brillo naranja. */
    private void drawLogoLine(DrawContext ctx, String line, int cx, float y, float scale) {
        Text text = Text.literal(line).formatted(Formatting.BOLD);
        int x = -textRenderer.getWidth(text) / 2;
        MatrixStack m = ctx.getMatrices();

        m.push();
        m.translate(cx, y, 0);
        m.scale(scale, scale, 1f);

        // Brillo (halo)
        float[][] halo = {{-0.9f, 0}, {0.9f, 0}, {0, -0.9f}, {0, 0.9f}};
        for (float[] o : halo) {
            m.push();
            m.translate(o[0], o[1], 0);
            ctx.drawText(textRenderer, text, x, 0, 0x55FF8A1E, false);
            m.pop();
        }

        // Extrusión (capas oscuras hacia abajo-derecha)
        int[] depthColors = {0xFFFFA23A, 0xFFF2752B, 0xFFD9502A, 0xFFB93426, 0xFF8F2222};
        for (int i = depthColors.length; i >= 1; i--) {
            m.push();
            m.translate(i * 0.35f, i * 0.35f, 0);
            ctx.drawText(textRenderer, text, x, 0, depthColors[i - 1], false);
            m.pop();
        }

        // Cara frontal dorada
        ctx.drawText(textRenderer, text, x, 0, 0xFFFFE9A0, false);

        m.pop();
    }

    /** Botón de texto sin fondo, estilo del menú de la captura. */
    private static class MenuButton extends ButtonWidget {
        private final int color;

        MenuButton(int cx, int cy, int w, int h, Text label, int color, PressAction action) {
            super(cx - w / 2, cy - h / 2, w, h, label, action, DEFAULT_NARRATION_SUPPLIER);
            this.color = color;
        }

        @Override
        public void renderWidget(DrawContext ctx, int mouseX, int mouseY, float delta) {
            boolean hot = isHovered() || isFocused();
            float s = hot ? 2.5f : 2.0f;
            int c = hot ? 0xFFFFFFFF : color;

            MatrixStack m = ctx.getMatrices();
            m.push();
            m.translate(getX() + getWidth() / 2f, getY() + getHeight() / 2f, 0);
            m.scale(s, s, 1f);
            Text t = getMessage().copy().formatted(Formatting.BOLD);
            ctx.drawCenteredTextWithShadow(MinecraftClient.getInstance().textRenderer, t, 0, -4, c);
            m.pop();
        }
    }
}
