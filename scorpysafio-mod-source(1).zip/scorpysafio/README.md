# Scorpy Safio Title Screen — Fabric 1.21.1

Proyecto de mod de CLIENTE que reemplaza la pantalla principal de Minecraft por un menú SCORPY-SAFIO by sefixz.

Incluye:
- Fondo panorámico original estilo Minecraft: cielo espacial morado/rojo, árbol luminoso y personaje encapuchado.
- Logo de texto SCORPY / SAFIO con volumen y brillo naranja.
- Crédito BY SEFIXZ.
- Botones JUGAR (abre multijugador), OPCIONES y SALIR.
- Estrellas animadas cuando el fondo no se carga.

## Compilar en GitHub Actions
El repositorio debe contener el contenido de esta carpeta (build.gradle, settings.gradle, gradle.properties y src) en su raíz. El workflow `.github/workflows/build.yml` compila con Java 21 y publica el JAR como artifact.

## Instalar
Copia `scorpysafio-titlescreen-1.0.0.jar` a `mods` de una instancia Fabric 1.21.1 con Java 21. Es un mod de cliente: no se instala en el servidor dedicado; cada jugador que quiera ver este menú debe instalarlo en su propio juego.

## Personalizar
El fondo está en `src/main/resources/assets/scorpysafio/textures/gui/background.png` (1920x1080). Los textos y botones están en `ScorpyTitleScreen.java`.
